use crate::diagnostics::{DiagnosticEvent, LogLevel, Source};
use crate::error::ErrorKind;
use crate::models::{OperationResult, PushPayload};
use crate::ui::messages::{Message, StatusSeverity};
use crate::ui::state::{ConnectionStatus, MainWindow};
use iced::Task;
use std::sync::Arc;

pub fn handle_hardware(window: &mut MainWindow, message: Message) -> Task<Message> {
    match message {
        Message::PullPressed => {
            if window.worker.is_none()
                || window.operation_lock.is_pulling
                || window.operation_lock.is_pushing
                || window.operation_lock.is_connecting
            {
                return Task::none();
            }

            if window.editor_state.is_dirty {
                window.editor_state.pending_confirm = crate::ui::state::ConfirmAction::PullDevice;
                return Task::none();
            }

            perform_pull(window)
        }
        Message::ConfirmPullPressed => {
            window.editor_state.pending_confirm = crate::ui::state::ConfirmAction::None;
            perform_pull(window)
        }
        Message::PushPressed => {
            if window.worker.is_none()
                || window.operation_lock.is_pulling
                || window.operation_lock.is_pushing
                || window.operation_lock.is_connecting
            {
                return Task::none();
            }
            window.operation_lock.is_pushing = true;
            window.diagnostics.push(DiagnosticEvent::new(
                LogLevel::Info,
                Source::UI,
                "Push pressed",
            ));
            let worker = match window.worker.as_ref() {
                Some(w) => Arc::clone(w),
                None => return Task::none(),
            };
            let filters = window.editor_state.filters.clone();
            let global_gain = window.editor_state.global_gain;
            let push_task = Task::perform(
                async move {
                    let payload = PushPayload {
                        filters,
                        global_gain: Some(global_gain),
                    };
                    let rx = worker.push_peq(payload);
                    recv_operation_result(rx)
                },
                Message::WorkerPushed,
            );
            let status_task = window.set_status("Writing to device...", StatusSeverity::Info);
            Task::batch(vec![push_task, status_task])
        }
        Message::WorkerPulled(result) => {
            window.operation_lock.is_pulling = false;
            if result.success {
                window.editor_state.is_dirty = false;
                if let Some(peq) = result.data {
                    window.editor_state.filters = peq.filters;
                    window.editor_state.global_gain = peq.global_gain;
                    window.diagnostics.push(DiagnosticEvent::new(
                        LogLevel::Info,
                        Source::Worker,
                        "Pull successful",
                    ));
                    return window.set_status("Data pulled from device", StatusSeverity::Success);
                }
                Task::none()
            } else if let Some(err) = result.error {
                let msg = if err.kind == ErrorKind::NotConnected
                    || err.kind == ErrorKind::PolkitAuthRequired
                {
                    window.connection_status =
                        ConnectionStatus::Error("Device lost during operation".into());
                    "Device lost during operation".to_string()
                } else {
                    window.connection_status =
                        ConnectionStatus::Error(err.user_message().to_string());
                    err.user_message().to_string()
                };
                window.diagnostics.push(DiagnosticEvent::new(
                    LogLevel::Error,
                    Source::Worker,
                    format!("Pull failed: {}", err.message),
                ));
                if let Some(context) = err.context.clone() {
                    window.diagnostics.push(DiagnosticEvent::new(
                        LogLevel::Error,
                        Source::Worker,
                        context,
                    ));
                }
                window.set_status(format!("Pull failed: {}", msg), StatusSeverity::Error)
            } else {
                Task::none()
            }
        }
        Message::WorkerPushed(result) => {
            window.operation_lock.is_pushing = false;
            if result.success {
                window.editor_state.is_dirty = false;
                if let Some(peq) = result.data {
                    window.editor_state.filters = peq.filters;
                    window.editor_state.global_gain = peq.global_gain;
                    window.diagnostics.push(DiagnosticEvent::new(
                        LogLevel::Info,
                        Source::Worker,
                        "Push successful",
                    ));
                    return window
                        .set_status("Settings applied and verified", StatusSeverity::Success);
                }
                Task::none()
            } else if let Some(err) = result.error {
                let base_msg = if err.kind == ErrorKind::NotConnected {
                    window.connection_status =
                        ConnectionStatus::Error("Device lost during operation".into());
                    "Device lost during operation".to_string()
                } else if err.kind == ErrorKind::DeviceLost {
                    window.connection_status =
                        ConnectionStatus::Error("Device disconnected".into());
                    window.disconnect_reason = crate::ui::state::DisconnectReason::DeviceLost;
                    "Device disconnected. Please reconnect and try again.".to_string()
                } else if err.kind == ErrorKind::DeviceBusy {
                    "Device is busy. Close other applications using the device and retry."
                        .to_string()
                } else if err.kind == ErrorKind::ReadTimeout {
                    "Read timeout. Device may be unresponsive. Try reconnecting.".to_string()
                } else if err.kind == ErrorKind::PolkitAuthRequired {
                    "Authentication required to access USB DAC on Linux. Approve the polkit prompt and retry.".to_string()
                } else {
                    window.connection_status =
                        ConnectionStatus::Error(err.user_message().to_string());
                    err.user_message().to_string()
                };

                let full_msg = format!(
                    "Push failed: {}. Try reading from device to resync.",
                    base_msg
                );

                window.diagnostics.push(DiagnosticEvent::new(
                    LogLevel::Error,
                    Source::Worker,
                    format!("Push failed: {}", err.message),
                ));
                if let Some(context) = err.context.clone() {
                    window.diagnostics.push(DiagnosticEvent::new(
                        LogLevel::Error,
                        Source::Worker,
                        context,
                    ));
                }
                window.set_status(full_msg, StatusSeverity::Error)
            } else {
                Task::none()
            }
        }
        _ => Task::none(),
    }
}

fn recv_operation_result(rx: std::sync::mpsc::Receiver<OperationResult>) -> OperationResult {
    match rx.recv_timeout(std::time::Duration::from_secs(5)) {
        Ok(res) => res,
        Err(std::sync::mpsc::RecvTimeoutError::Timeout) => OperationResult::timed_out(),
        Err(std::sync::mpsc::RecvTimeoutError::Disconnected) => OperationResult::worker_gone(),
    }
}

fn perform_pull(window: &mut MainWindow) -> Task<Message> {
    window.operation_lock.is_pulling = true;
    window.diagnostics.push(DiagnosticEvent::new(
        LogLevel::Info,
        Source::UI,
        "Pulling from device",
    ));
    let worker = match window.worker.as_ref() {
        Some(w) => Arc::clone(w),
        None => return Task::none(),
    };
    let pull_task = Task::perform(
        async move {
            let rx = worker.pull_peq();
            recv_operation_result(rx)
        },
        Message::WorkerPulled,
    );
    let status_task = window.set_status("Reading from device...", StatusSeverity::Info);
    Task::batch(vec![pull_task, status_task])
}
