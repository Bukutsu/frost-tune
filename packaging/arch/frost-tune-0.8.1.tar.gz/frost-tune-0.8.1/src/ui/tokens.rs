use iced::Color;

use crate::ui::theme::{
    TOKYO_NIGHT_BG, TOKYO_NIGHT_BG_DARK, TOKYO_NIGHT_BG_HIGHLIGHT, TOKYO_NIGHT_BLUE,
    TOKYO_NIGHT_COMMENT, TOKYO_NIGHT_FG, TOKYO_NIGHT_GREEN, TOKYO_NIGHT_RED, TOKYO_NIGHT_YELLOW,
};

// Material 3 role-oriented tokens mapped to Tokyo Night.
pub const M3_COLOR_SURFACE: Color = TOKYO_NIGHT_BG_HIGHLIGHT;
pub const M3_COLOR_SURFACE_VARIANT: Color = TOKYO_NIGHT_BG_DARK;
pub const M3_COLOR_BACKGROUND: Color = TOKYO_NIGHT_BG;
pub const M3_COLOR_ON_SURFACE: Color = TOKYO_NIGHT_FG;
pub const M3_COLOR_ON_SURFACE_VARIANT: Color = TOKYO_NIGHT_COMMENT;
pub const M3_COLOR_PRIMARY: Color = TOKYO_NIGHT_BLUE;
pub const M3_COLOR_SUCCESS: Color = TOKYO_NIGHT_GREEN;
pub const M3_COLOR_WARNING: Color = TOKYO_NIGHT_YELLOW;
pub const M3_COLOR_ERROR: Color = TOKYO_NIGHT_RED;

// Window-class helpers for adaptive layout decisions.
pub const WINDOW_NARROW_MAX: f32 = 999.0;
pub const WINDOW_MEDIUM_MAX: f32 = 1279.0;
pub const WINDOW_MAX_CONTENT_WIDTH: f32 = 1280.0;
pub const SIDEBAR_WIDTH: f32 = 320.0;

// Spacing scale.
pub const SPACE_1: f32 = 1.0;
pub const SPACE_2: f32 = 2.0;
pub const SPACE_4: f32 = 4.0;
pub const SPACE_6: f32 = 6.0;
pub const SPACE_8: f32 = 8.0;
pub const SPACE_10: f32 = 10.0;
pub const SPACE_12: f32 = 12.0;
pub const SPACE_16: f32 = 16.0;
pub const SPACE_20: f32 = 20.0;
pub const SPACE_24: f32 = 24.0;
pub const SPACE_32: f32 = 32.0;
pub const SPACE_40: f32 = 40.0;

// Typography scale.
pub const TYPE_DISPLAY: f32 = 32.0;
pub const TYPE_TITLE: f32 = 22.0;
pub const TYPE_SUBTITLE: f32 = 18.0;
pub const TYPE_BODY: f32 = 16.0;
pub const TYPE_LABEL: f32 = 13.0;
pub const TYPE_CAPTION: f32 = 11.0;
pub const TYPE_TINY: f32 = 9.0;

// Control metrics.
pub const BUTTON_VERTICAL_PADDING: f32 = 10.0;
pub const BUTTON_HORIZONTAL_PADDING: f32 = 16.0;
pub const INPUT_HEIGHT: f32 = 36.0;

// Icons
pub const ICON_FONT: iced::Font = iced::Font::with_name("Material Icons");
pub const ICON_FOLDER: &str = "\u{e2c7}";
pub const ICON_RELOAD: &str = "\u{e5d5}";
pub const ICON_CLOSE: &str = "\u{e5cd}";
pub const ICON_IMPORT_FILE: &str = "\u{e2c4}";
pub const ICON_EXPORT_FILE: &str = "\u{e2c6}";
pub const ICON_IMPORT_CLIPBOARD: &str = "\u{e14f}";
pub const ICON_EXPORT_CLIPBOARD: &str = "\u{e173}";
pub const ICON_FONT_BYTES: &[u8] = include_bytes!("../../assets/MaterialIcons-Regular.ttf");
