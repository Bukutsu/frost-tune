use crate::models::Device;
use crate::ui::messages::Message;
use crate::ui::state::{ConnectionStatus, MainWindow};
use crate::ui::theme::{self, TOKYO_NIGHT_MUTED, TOKYO_NIGHT_PRIMARY};
use crate::ui::tokens::{
    SPACE_12, SPACE_16, SPACE_2, SPACE_4, SPACE_6, SPACE_8, TYPE_BODY, TYPE_CAPTION, TYPE_TINY,
    TYPE_TITLE,
};
use crate::ui::views::toolbar_button;
use iced::font::Weight;
use iced::widget::{column, container, row, text, tooltip};
use iced::{Element, Font, Length};

pub fn view_header(state: &MainWindow) -> Element<'_, Message> {
    let is_busy = state.operation_lock.is_pulling
        || state.operation_lock.is_pushing
        || state.operation_lock.is_connecting
        || state.operation_lock.is_disconnecting;

    let is_connected = state.connection_status == ConnectionStatus::Connected;

    let sync_buttons = row![
        if !is_busy && is_connected {
            Element::from(
                toolbar_button("Read")
                    .on_press(Message::PullPressed)
                    .style(theme::pill_secondary_button),
            )
        } else {
            let btn = toolbar_button("Read").style(theme::pill_secondary_button);
            if let Some(reason) = state.disabled_reason_for_action("read") {
                Element::from(
                    tooltip(btn, text(reason), tooltip::Position::Bottom)
                        .style(theme::tooltip_style),
                )
            } else {
                Element::from(btn)
            }
        },
        if !is_busy && is_connected && !state.editor_state.input_buffer.has_errors() {
            Element::from(
                toolbar_button("Write")
                    .on_press(Message::PushPressed)
                    .style(|theme, status| {
                        let mut s = theme::pill_primary_button(theme, status);
                        if matches!(status, iced::widget::button::Status::Active) {
                            s.background = Some(iced::Background::Color(theme::ACCENT_VIBRANT));
                            s.text_color = theme::TOKYO_NIGHT_BG_DARK;
                        }
                        s
                    }),
            )
        } else {
            let btn = toolbar_button("Write").style(theme::pill_primary_button);
            if let Some(reason) = state.disabled_reason_for_action("write") {
                Element::from(
                    tooltip(btn, text(reason), tooltip::Position::Bottom)
                        .style(theme::tooltip_style),
                )
            } else {
                Element::from(btn)
            }
        },
        if !is_busy && is_connected {
            Element::from(
                toolbar_button("Disconnect")
                    .on_press(Message::DisconnectPressed)
                    .style(theme::pill_secondary_button),
            )
        } else {
            let btn = toolbar_button("Disconnect").style(theme::pill_secondary_button);
            if let Some(reason) = state.disabled_reason_for_action("disconnect") {
                Element::from(
                    tooltip(btn, text(reason), tooltip::Position::Bottom)
                        .style(theme::tooltip_style),
                )
            } else {
                Element::from(btn)
            }
        },
    ]
    .spacing(SPACE_8);

    let status_indicator = match &state.connection_status {
        ConnectionStatus::Connected => container(
            text("SYNCED")
                .size(TYPE_TINY)
                .color(theme::TOKYO_NIGHT_BG_DARK),
        )
        .padding([SPACE_2, SPACE_6])
        .style(|_theme| container::Style {
            background: Some(theme::TOKYO_NIGHT_SUCCESS.into()),
            border: iced::Border {
                radius: 4.0.into(),
                ..Default::default()
            },
            ..Default::default()
        }),
        ConnectionStatus::Connecting => container(
            text("CONNECTING")
                .size(TYPE_TINY)
                .color(theme::TOKYO_NIGHT_BG_DARK),
        )
        .padding([SPACE_2, SPACE_6])
        .style(|_theme| container::Style {
            background: Some(theme::TOKYO_NIGHT_YELLOW.into()),
            border: iced::Border {
                radius: 4.0.into(),
                ..Default::default()
            },
            ..Default::default()
        }),
        _ => container(
            text("OFFLINE")
                .size(TYPE_TINY)
                .color(theme::TOKYO_NIGHT_FG_DARK),
        )
        .padding([SPACE_2, SPACE_6])
        .style(|_theme| container::Style {
            background: Some(theme::TOKYO_NIGHT_TERMINAL_BLACK.into()),
            border: iced::Border {
                radius: 4.0.into(),
                ..Default::default()
            },
            ..Default::default()
        }),
    };

    let device_info = if let Some(ref dev) = state.connected_device {
        let device_type = Device::from_vid_pid(dev.vendor_id, dev.product_id);
        row![
            text(device_type.name())
                .size(TYPE_BODY)
                .color(TOKYO_NIGHT_PRIMARY)
                .font(Font {
                    weight: Weight::Bold,
                    ..Default::default()
                }),
            text(format!(
                " (VID:{:04X} PID:{:04X})",
                dev.vendor_id, dev.product_id
            ))
            .size(TYPE_CAPTION)
            .color(TOKYO_NIGHT_MUTED),
        ]
        .align_y(iced::Alignment::Center)
        .spacing(SPACE_4)
    } else {
        row![text("No device detected")
            .size(TYPE_BODY)
            .color(TOKYO_NIGHT_MUTED)]
    };

    container(
        row![
            column![
                row![
                    text("Frost-Tune")
                        .size(TYPE_TITLE)
                        .color(TOKYO_NIGHT_PRIMARY)
                        .font(Font {
                            weight: Weight::Bold,
                            ..Default::default()
                        }),
                    status_indicator,
                ]
                .spacing(SPACE_12)
                .align_y(iced::Alignment::Center),
                device_info,
            ]
            .spacing(SPACE_2),
            container(text("")).width(Length::Fill),
            if is_busy {
                container(
                    text("Device busy...")
                        .size(TYPE_CAPTION)
                        .color(theme::TOKYO_NIGHT_BLUE),
                )
                .padding([0.0, SPACE_16])
            } else {
                container(text("")).width(Length::Shrink)
            },
            sync_buttons,
        ]
        .padding(SPACE_16)
        .spacing(SPACE_16)
        .align_y(iced::Alignment::Center),
    )
    .style(theme::header_card_style)
    .width(Length::Fill)
    .into()
}
